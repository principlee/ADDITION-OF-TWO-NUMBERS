/*
Introduction to programing
Addition of two numbers
By EJO
@Laaw1
*/
#include<stdio.h>
int main()
{
    int x, y;

    printf("Enter value of x and y\n");
    scanf("%d %d", &x, &y);

    printf("Addition of %d and %d = %d\n", x, y, (x+y));
return 0;
}
